# 😎 Emoji Maker

Photo chuno, aur wahi photo emoji mosaic ban jaati hai. Capacitor se Android APK banta hai, aur GitHub Actions APK khud build karta hai.

## APK kaise milega

1. GitHub par naya repo banao (jaise `emoji-maker`).
2. Is folder ki saari files upload karo (`.github` folder samet).
3. Repo mein **Actions** tab kholo. "Build APK" workflow khud chalega (3-5 minute).
4. Workflow poora hone par us run ke neeche **Artifacts** mein `emoji-maker-apk` download karo.
5. Zip kholo, `app-debug.apk` phone mein bhejo aur install karo. Settings mein "Unknown sources" allow karna pad sakta hai.

## Folder

- `www/index.html`: poori app (HTML, CSS, JS)
- `capacitor.config.json`: app ka naam aur ID
- `.github/workflows/build-apk.yml`: APK build karne ke steps

## Note

Yeh debug APK hai, personal use ke liye. Play Store ke liye signed release build chahiye hogi.
